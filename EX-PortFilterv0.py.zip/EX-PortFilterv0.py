import re
import argparse
import subprocess
import sys

def nmap_filter(nmap_output):
    ip_pattern = r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}"
    port_pattern = r"(\b\d+\b\/\w+)"

    filtered_data = []

    for line in nmap_output.splitlines():
        if "open" not in line:
            continue

        match_ip = re.search(ip_pattern,line)
        if not match_ip:
            continue

        ip_address = match_ip.group(0)

        matches_ports= re.findall(port_pattern,line)

        if len(matches_ports)>0:
            filtered_data.append((ip_address,list(set(matches_ports))))

    return filtered_data


def scan_ports(target, port_range):
    nmap_args = ["nmap", "-p", port_range, "-sS", "-oG", "-"]
    nmap_process = subprocess.Popen(nmap_args + [target], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    nmap_output, nmap_error = nmap_process.communicate()

    if nmap_error:
        print(f"Error running Nmap: {nmap_error}")
        sys.exit(1)

    filtered_data = nmap_filter(nmap_output.decode("utf-8"))
    return filtered_data


def main():
    parser = argparse.ArgumentParser(description="Simple Nmap port scanner")
    parser.add_argument("target", help="Target IP address or hostname")
    parser.add_argument("port_range", help="Port range to scan (e.g. 1-100)")
    args = parser.parse_args()

    if not os.geteuid() == 0:
        print("You need root privileges to run this script")
        sys.exit(1)

    target = args.target
    port_range = args.port_range

    print(f"Scanning {target} for open ports in range {port_range}...")
    filtered_data = scan_ports(target, port_range)

    if filtered_data:
        for ip_address, open_ports in filtered_data:
            print(f"Open ports for {ip_address}: {', '.join(open_ports)}")
    else:
        print(f"No open ports found for {target}")


if __name__ == "__main__":
    main()
